using LibraryManagementSystem.Interfaces;
using LibraryManagementSystem.Middleware;
using LibraryManagementSystem.Repositories;
using LibraryManagementSystem.Services;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http.Features;

var builder = WebApplication.CreateBuilder(args);

builder.Services.Configure<IISServerOptions>(options =>
{
    options.MaxRequestBodySize = int.MaxValue; 
});

builder.Services.Configure<FormOptions>(options =>
{
    options.MultipartBodyLengthLimit = long.MaxValue; 
});


builder.Services.AddTransient<DapperDbContext, DapperDbContext>();
builder.Services.AddTransient<IBook, BookRepository>();
builder.Services.AddTransient<IApplicationUser, ApplicationUserRepository>();



builder.Services.AddControllersWithViews();
builder.Services.AddDistributedMemoryCache();  // Add memory cache to support session.
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30);  // Set session timeout duration.
    options.Cookie.IsEssential = true;  // Make session cookie essential.
});

// Add Cookie Authentication service
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login"; 
        options.AccessDeniedPath = "/Account/AccessDenied"; 
    });

builder.Services.AddScoped<IUserService, UserService>(); 
builder.Services.AddHttpContextAccessor();  

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();


app.UseAuthentication(); //  middleware
app.UseSession();  //  session
app.UseAuthorization(); // authorization middleware

app.UseMiddleware<RoleMiddleware>(); 


app.UseEndpoints(endpoints =>
{
    endpoints.MapControllerRoute(
        name: "default",
        pattern: "{controller=Home}/{action=Index}/{id?}");
});

app.Run();
