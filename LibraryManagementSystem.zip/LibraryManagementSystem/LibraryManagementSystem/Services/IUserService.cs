﻿using LibraryManagementSystem.Models;
using static LibraryManagementSystem.Services.UserService;

namespace LibraryManagementSystem.Services
{
    public interface IUserService
    {
        RegisterResult RegisterUser(RegisterModel model);
        LoginResult LoginUser(LoginModel model, out ApplicationUser loggedInUser);
    }
}
