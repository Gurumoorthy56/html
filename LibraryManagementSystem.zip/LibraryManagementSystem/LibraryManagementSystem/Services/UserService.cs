﻿using Microsoft.Data.SqlClient;
using Dapper;
using System.Security.Cryptography;
using System.Text;
using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.Services
{
    public class UserService : IUserService
    {
        private readonly string _connectionString;

        public UserService(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public enum RegisterResult
        {
            Success,
            EmailExists,
            Error
        }

        public RegisterResult RegisterUser(RegisterModel model)
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    // here checking if email already exists
                    var existingUser = connection.QueryFirstOrDefault<int>(
                        "SELECT 1 FROM Users WHERE Email = @Email",
                        new { model.Email });

                    if (existingUser != 0)
                    {
                        return RegisterResult.EmailExists;
                    }

                    string hashedPassword = HashPassword(model.Password);
                    var query = @"
                INSERT INTO Users 
                (Id, Username, PasswordHash, Role, Name, Email, PhoneNumber, AddressLine1, City, Code, Country, InvoiceEmail, 
                Language, LastName, PostalCode, Salutation, Street, Telephone) 
                VALUES 
                (NEWID(), @Username, @PasswordHash, @Role, @Name, @Email, @PhoneNumber, @AddressLine1, @City, @Code, @Country, @InvoiceEmail, 
                @Language, @LastName, @PostalCode, @Salutation, @Street, @Telephone)";

                    connection.Execute(query, new
                    {
                        model.Username,
                        PasswordHash = hashedPassword,
                        model.Role,
                        model.Name,
                        model.Email,
                        model.PhoneNumber,
                        model.AddressLine1,
                        model.City,
                        model.Code,
                        model.Country,
                        model.InvoiceEmail,
                        model.Language,
                        model.LastName,
                        model.PostalCode,
                        model.Salutation,
                        model.Street,
                        model.Telephone
                    });

                    return RegisterResult.Success;
                }
            }
            catch (Exception)
            {
                return RegisterResult.Error;
            }
        }

        public enum LoginResult
        {
            Success = 1,
            EmailNotFound = -1,
            InvalidPassword = 0
        }

        public LoginResult LoginUser(LoginModel model, out ApplicationUser loggedInUser)
        {
            loggedInUser = null;
            using (var connection = new SqlConnection(_connectionString))
            {
                var query = "SELECT * FROM Users WHERE Username = @Username";
                var user = connection.QueryFirstOrDefault<ApplicationUser>(query, new { model.Username });

                if (user == null)
                    return LoginResult.EmailNotFound;

                if (VerifyPassword(model.Password, user.PasswordHash))
                {
                    loggedInUser = user;
                    return LoginResult.Success;
                }

                return LoginResult.InvalidPassword;
            }
        }
        private string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(bytes);
            }
        }

        private bool VerifyPassword(string password, string hashedPassword)
        {
            return HashPassword(password) == hashedPassword;
        }
    }
}
