﻿using LibraryManagementSystem.Interfaces;
using LibraryManagementSystem.Models;
using LibraryManagementSystem.Services;
using Dapper;

namespace LibraryManagementSystem.Repositories
{
    public class BookRepository : IBook
    {
        private readonly DapperDbContext context;

        public BookRepository(DapperDbContext context)
        {
            this.context = context;
        }

        public async Task<IEnumerable<BookModel>> Get()
        {
            var sql = $@"SELECT [ISBN],
                                [BookTitle],
                                [Author],
                                [AboutAuthor],
                                [Genre],
                                [Tags],
                                [PublishYear],
                                [Publisher],
                                [NumberOfPages],
                                [Price],
                                [Edition],
                                [Language],
                                [Summary],
                                [CoverImage],
                                [Contributor],
                                [AddedDate]
                         FROM
                                [Books]";

            using var connection = context.CreateConnection();
            return await connection.QueryAsync<BookModel>(sql);
        }

        public async Task<BookModel> Find(string isbn)
        {
            var sql = $@"SELECT [ISBN],
                                [BookTitle],
                                [Author],
                                [AboutAuthor],
                                [Genre],
                                [Tags],
                                [PublishYear],
                                [Publisher],
                                [NumberOfPages],
                                [Price],
                                [Edition],
                                [Language],
                                [Summary],
                                [CoverImage],
                                [Contributor],
                                [AddedDate]
                         FROM
                                [Books]
                         WHERE
                               [ISBN]=@isbn";

            using var connection = context.CreateConnection();
            return await connection.QueryFirstOrDefaultAsync<BookModel>(sql, new { isbn });
        }

        public async Task<BookModel> Add(BookModel model)
        {
            model.AddedDate = DateTime.Now; // Setting current date and time
            var sql = $@"INSERT INTO [dbo].[Books]
                             ([ISBN], 
                              [BookTitle], 
                              [Author], 
                              [AboutAuthor], 
                              [Genre], 
                              [Tags], 
                              [PublishYear], 
                              [Publisher], 
                              [NumberOfPages], 
                              [Price], 
                              [Edition], 
                              [Language], 
                              [Summary], 
                              [CoverImage], 
                              [Contributor], 
                              [AddedDate])
                         VALUES
                             (@ISBN, 
                              @BookTitle, 
                              @Author, 
                              @AboutAuthor, 
                              @Genre, 
                              @Tags, 
                              @PublishYear, 
                              @Publisher, 
                              @NumberOfPages, 
                              @Price, 
                              @Edition, 
                              @Language, 
                              @Summary, 
                              @CoverImage, 
                              @Contributor, 
                              @AddedDate)";

            using var connection = context.CreateConnection();
            try
            {

                var rowsAffected = await connection.ExecuteAsync(sql, model);

                if (rowsAffected > 0)
                {
                    return model;
                }
                else
                {
                    throw new Exception("No rows were affected. The book could not be added.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
                throw;
            }

        }

        public async Task<BookModel> Update(BookModel model)
        {
            var sql = $@"UPDATE[dbo].[Books]
                         SET    [BookTitle] = @BookTitle,
                                [Author] = @Author,
                                [AboutAuthor] = @AboutAuthor,
                                [Genre] = @Genre,
                                [Tags] = @Tags,
                                [PublishYear] = @PublishYear,
                                [Publisher] = @Publisher,
                                [NumberOfPages] = @NumberOfPages,
                                [Price] = @Price,
                                [Edition] = @Edition,
                                [Language] = @Language,
                                [Summary] = @Summary,
                                [CoverImage] = @CoverImage,
                                [Contributor] = @Contributor
                         WHERE
                               ISBN=@ISBN";

            using var connection = context.CreateConnection();
            await connection.ExecuteAsync(sql, model);
            return model;
        }

        public async Task<BookModel> Remove(BookModel model)
        {
            var sql = $@"DELETE FROM
                            [dbo].[Books]
                         WHERE
                            ISBN=@isbn";

            using var connection = context.CreateConnection();
            await connection.ExecuteAsync(sql, model);
            return model;
        }
    }
}
