﻿using LibraryManagementSystem.Interfaces;
using LibraryManagementSystem.Models;
using LibraryManagementSystem.Services;
using Dapper;

namespace LibraryManagementSystem.Repositories
{
    public class ApplicationUserRepository : IApplicationUser
    {
        private readonly DapperDbContext context;

        public ApplicationUserRepository(DapperDbContext context)
        {
            this.context = context;
        }

        public async Task<IEnumerable<ApplicationUser>> Get()
        {
            var sql = $@"SELECT [Id],
                        [Name],
                        [ProfilePicture],
                        [Email],
                        [AddressLine1],
                        [City],
                        [Code],
                        [Country],
                        [InvoiceEmail],
                        [Language],
                        [LastName],
                        [PostalCode],
                        [Salutation],
                        [Street],
                        [Telephone]
                 FROM
                        [Users]";

            using var connection = context.CreateConnection();
            return await connection.QueryAsync<ApplicationUser>(sql);
        }

        public async Task<ApplicationUser> Find(string id)
        {
            var sql = $@"SELECT [Id],
                        [Name],
                        [ProfilePicture],
                        [Email],
                        [AddressLine1],
                        [City],
                        [Code],
                        [Country],
                        [InvoiceEmail],
                        [Language],
                        [LastName],
                        [PostalCode],
                        [Salutation],
                        [Street],
                        [Telephone]
                 FROM
                        [Users]
                 WHERE
                        [Id] = @id";

            using var connection = context.CreateConnection();
            return await connection.QueryFirstOrDefaultAsync<ApplicationUser>(sql, new { id });
        }

        public async Task<ApplicationUser> Remove(ApplicationUser model)
        {
            var sql = $@"DELETE FROM
                     [Users]
                  WHERE
                     Id = @id";

            using var connection = context.CreateConnection();
            await connection.ExecuteAsync(sql, new { id = model.Id });
            return model;
        }

    }
}
