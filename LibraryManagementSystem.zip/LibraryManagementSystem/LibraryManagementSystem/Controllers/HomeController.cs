using System.Diagnostics;
using Dapper;
using System.Security.Claims;
using LibraryManagementSystem.Models;
using LibraryManagementSystem.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

namespace LibraryManagementSystem.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly DapperDbContext _dbContext;

        public HomeController(DapperDbContext dbContext, ILogger<HomeController> logger)
        {
            _dbContext = dbContext;
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        [Authorize(Roles = "User")]
        public IActionResult Browse()
        {
            return View();
        }

        [Authorize]
        public IActionResult MyBooks()
        {
            string userId = HttpContext.Session.GetString("UserId"); // Get logged-in user ID

            using (var connection = _dbContext.CreateConnection())
            {
                var query = @"SELECT *
                      FROM UserBooks ub 
                      JOIN Books b ON ub.ISBN = b.ISBN 
                      WHERE ub.Id = @UserId";

                var books = connection.Query<BookModel>(query, new { UserId = userId }).ToList();

                return View(books); // Pass the list of books to the view
            }
        }



        [Authorize]
        public IActionResult Wishlist()
        {
            string userId = HttpContext.Session.GetString("UserId"); // Get logged-in user ID

            using (var connection = _dbContext.CreateConnection())
            {
                var query = @"
                SELECT b.ISBN, b.BookTitle, b.Author
                FROM UserWishlist uw
                JOIN Books b ON uw.ISBN = b.ISBN
                WHERE uw.Id = @UserId";

                var wishlistBooks = connection.Query<BookModel>(query, new { UserId = userId }).ToList();

                return View(wishlistBooks);
            }
        }

        [HttpPost]
        [Authorize]
        public IActionResult IssueBook(string userId, string isbn)
        {
            if (string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(isbn))
            {
                return Json(new { success = false, message = "UserId or ISBN is invalid." });
            }

            try
            {
                // Check if the book exists in the Books table
                var bookExists = _dbContext.CreateConnection().QueryFirstOrDefault<BookModel>(
                    "SELECT * FROM Books WHERE ISBN = @ISBN", new { ISBN = isbn });

                if (bookExists == null)
                {
                    return Json(new { success = false, message = "Book not found." });
                }

                // Check if the user already owns the book (it is already in UserBooks)
                var bookAlreadyOwned = _dbContext.CreateConnection().QueryFirstOrDefault<BookModel>(
                    "SELECT * FROM UserBooks WHERE Id = @UserId AND ISBN = @ISBN", new { UserId = userId, ISBN = isbn });

                if (bookAlreadyOwned != null)
                {
                    return Json(new { success = false, message = "You already own this book." });
                }

                // Add the book to UserRequest table
                var insertQuery = @"INSERT INTO UserRequest (Id, ISBN) VALUES (@UserId, @ISBN)";
                _dbContext.CreateConnection().Execute(insertQuery, new { UserId = userId, ISBN = isbn });

                // Remove the book from UserWishlist table
                var deleteQuery = @"DELETE FROM UserWishlist WHERE Id = @UserId AND ISBN = @ISBN";
                _dbContext.CreateConnection().Execute(deleteQuery, new { UserId = userId, ISBN = isbn });

                return Json(new { success = true, message = "Book Request Sent !" });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }


        [HttpPost]
        [Authorize]
        public IActionResult RemoveFromWishlist(string userId, string isbn)
        {
            if (string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(isbn))
            {
                return Json(new { success = false, message = "UserId or ISBN is invalid." });
            }

            try
            {
                // Remove the book from UserWishlist table
                var deleteQuery = @"DELETE FROM UserWishlist WHERE Id = @UserId AND ISBN = @ISBN";
                _dbContext.CreateConnection().Execute(deleteQuery, new { UserId = userId, ISBN = isbn });

                return Json(new { success = true, message = "Book successfully removed from wishlist." });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        [HttpPost]
        [Authorize]
        public IActionResult AddToWishlist(string userId, string isbn)
        {
            if (string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(isbn))
            {
                return Json(new { success = false, message = "UserId or ISBN is invalid." });
            }

            try
            {
                // Check if the book is already in the wishlist
                var existingWishlistItem = _dbContext.CreateConnection().QueryFirstOrDefault<UserWishlistModel>(
                    "SELECT * FROM UserWishlist WHERE Id = @UserId AND ISBN = @ISBN", new { UserId = userId, ISBN = isbn });

                if (existingWishlistItem != null)
                {
                    return Json(new { success = false, message = "This book is already in your wishlist." });
                }

                // Add the book to UserWishlist table
                var insertQuery = @"INSERT INTO UserWishlist (Id, ISBN) VALUES (@UserId, @ISBN)";
                _dbContext.CreateConnection().Execute(insertQuery, new { UserId = userId, ISBN = isbn });

                return Json(new { success = true, message = "Book successfully added to wishlist." });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
