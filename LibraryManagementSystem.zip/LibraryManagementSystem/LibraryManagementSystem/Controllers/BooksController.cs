﻿using LibraryManagementSystem.Services;
using System.Data;
using Microsoft.AspNetCore.Mvc;
using LibraryManagementSystem.Interfaces;
using Microsoft.AspNetCore.Authorization;
using LibraryManagementSystem.Models;
using Dapper;

namespace LibraryManagementSystem.Controllers
{
    public class BooksController : Controller
    {
        private readonly IDbConnection _dbConnection;
        private readonly IBook bookRepository;
        private readonly IWebHostEnvironment webHostEnvironment;

        public BooksController(IBook bookRepository, DapperDbContext dbContext, IWebHostEnvironment hostEnvironment)
        {
            this.bookRepository = bookRepository;
            _dbConnection = dbContext.CreateConnection();
            webHostEnvironment = hostEnvironment;
        }


        [Authorize (Roles ="Admin")]
        public async Task<IActionResult> Index(int page = 1)
        {
            int pageSize = 8; // Display 8 books per page
            int skip = (page - 1) * pageSize;

            var books = await bookRepository.Get();

            int totalBooks = books.Count();
            int totalPages = (int)Math.Ceiling((double)totalBooks / pageSize);

            var paginatedBooks = books.Skip(skip).Take(pageSize).ToList();

            var model = new BookListViewModel
            {
                Books = paginatedBooks,
                CurrentPage = page,
                TotalPages = totalPages
            };

            return View(model);
        }


        public async Task<IActionResult> GetAllBooks()
        {
            var books = await bookRepository.Get();
            return Json(books);
        }


        [Authorize]
        public async Task<IActionResult> Book(string isbn)
        {
            if (isbn == null)
            {

                return View("Index");
            }
            var book = await bookRepository.Find(isbn);

            if (book == null)
            {

                return NotFound();
            }

            return View(book);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]

        public IActionResult IssueBook(string userId, string isbn)
        {
            if (string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(isbn))
            {
                return Json(new { success = false, message = "UserId or ISBN is invalid." });
            }

            try
            {
                var bookExists = _dbConnection.QueryFirstOrDefault<BookModel>(
                    "SELECT * FROM Books WHERE ISBN = @ISBN", new { ISBN = isbn });

                if (bookExists == null)
                {
                    return Json(new { success = false, message = "Book not found." });
                }

                var bookAlreadyIssued = _dbConnection.QueryFirstOrDefault<UserBooksModel>(
                    "SELECT * FROM UserBooks WHERE Id = @UserId AND ISBN = @ISBN", new { UserId = userId, ISBN = isbn });

                if (bookAlreadyIssued != null)
                {
                    return Json(new { success = false, message = "You have already issued this book." });
                }

                var insertQuery = "INSERT INTO UserRequest (Id, ISBN) VALUES (@UserId, @ISBN)";
                _dbConnection.Execute(insertQuery, new { UserId = userId, ISBN = isbn });

                return Json(new { success = true, message = "Book successfully issued..." });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Details(string isbn)
        {
            if (isbn == null)
            {

                return View("Index");
            }
            var book = await bookRepository.Find(isbn);

            if (book == null)
            {

                return NotFound();
            }

            return View(book);
        }
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(BookModel model, IFormFile CoverImageFile)
        {
            if (ModelState.IsValid)
            {
                if (CoverImageFile != null && CoverImageFile.Length > 0)
                {

                    string uniqueFileName = Guid.NewGuid().ToString() + "_" + CoverImageFile.FileName;


                    string uploadsFolder = Path.Combine(webHostEnvironment.WebRootPath, "images", "covers");


                    if (!Directory.Exists(uploadsFolder))
                    {
                        Directory.CreateDirectory(uploadsFolder);
                    }

                    string filePath = Path.Combine(uploadsFolder, uniqueFileName);

                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        await CoverImageFile.CopyToAsync(fileStream);
                    }

                    model.CoverImage = uniqueFileName;
                }

                await bookRepository.Add(model);
                return RedirectToAction(nameof(Index));
            }
            return View(model);
        }

        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(string isbn)
        {
            if (isbn == null)
            {
                return NotFound();
            }

            var book = await bookRepository.Find(isbn);

            if (book == null)
            {
                return NotFound();
            }
            return View(book);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(string isbn, BookModel model)
        {
            if (isbn == null)
            {
                return NotFound();
            }
            var product = await bookRepository.Find(isbn);

            if (product == null)
            {
                return BadRequest();
            }
            await bookRepository.Update(model);
            return RedirectToAction(nameof(Index));

        }

        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(string isbn)
        {
            if (isbn == null)
            {
                return NotFound();
            }

            var product = await bookRepository.Find(isbn);

            if (product == null)
            {
                return BadRequest();
            }
            return View("Delete", product);
        }

        [HttpPost, ActionName("Delete")]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ConfirmDelete(string isbn)
        {
            if (string.IsNullOrEmpty(isbn))
            {
                return BadRequest("ISBN cannot be null or empty.");
            }
            var product = await bookRepository.Find(isbn);
            await bookRepository.Remove(product);
            return RedirectToAction(nameof(Index));
        }


    }
}
