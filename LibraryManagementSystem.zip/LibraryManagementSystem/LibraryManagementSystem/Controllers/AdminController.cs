﻿using System.Data;
using LibraryManagementSystem.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Dapper;
using LibraryManagementSystem.Services;

namespace LibraryManagementSystem.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        private readonly DapperDbContext _dbContext;

        public AdminController(DapperDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public IActionResult Dashboard()
        {

            return View();
        }

        public IActionResult Report()
        {

            return View();
        }

        [Authorize(Roles = "Admin")]
        public IActionResult RequestedBooks()
        {
            using (var connection = _dbContext.CreateConnection())
            {
                var query = @"
        SELECT ur.Id , 
               b.ISBN, 
               b.BookTitle, 
               b.Author, 
               u.UserName
        FROM UserRequest ur
        JOIN Books b ON ur.ISBN = b.ISBN
        JOIN Users u ON ur.Id = u.Id";

                var requestedBooks = connection.Query<UserRequestModel, BookModel, ApplicationUser, RequestedBookViewModel>(
                    query,
                    (ur, b, u) =>
                    {
                        // Debugging null values here
                        if (ur == null)
                        {
                            Console.WriteLine("UserRequestModel is null");
                        }
                        if (b == null)
                        {
                            Console.WriteLine("BookModel is null");
                        }
                        if (u == null)
                        {
                            Console.WriteLine("ApplicationUser is null");
                        }

                        return new RequestedBookViewModel
                        {
                            UserId = ur.Id,
                            ISBN = b?.ISBN,
                            Title = b?.BookTitle,
                            Author = b?.Author,
                            UserName = u?.UserName
                        };
                    },
                    splitOn: "ISBN,UserName"
                ).ToList();

                return View(requestedBooks);
            }
        }



        [HttpPost]
        [Authorize(Roles = "Admin")]
        public IActionResult AcceptRequest(string userId, string isbn)
        {
            if (string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(isbn))
            {
                TempData["Error"] = "UserId or ISBN is null or empty";
                return RedirectToAction("RequestedBooks");
            }

            IDbConnection connection = _dbContext.CreateConnection();
            if (connection == null)
            {
                TempData["Error"] = "Database connection failed.";
                return RedirectToAction("RequestedBooks");
            }

            connection.Open();
            using (var transaction = connection.BeginTransaction())
            {
                try
                {
                    var insertQuery = @"INSERT INTO UserBooks (Id, ISBN) VALUES (@UserId, @ISBN)";
                    connection.Execute(insertQuery, new { UserId = userId, ISBN = isbn }, transaction);
                    var deleteQuery = @"DELETE FROM UserRequest WHERE Id = @UserId AND ISBN = @ISBN";
                    connection.Execute(deleteQuery, new { UserId = userId, ISBN = isbn }, transaction);
                    transaction.Commit();
                    TempData["Success"] = "Request accepted successfully";
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    TempData["Error"] = ex.Message;
                }
                finally
                {
                    connection.Close();
                }
            }
            return RedirectToAction("RequestedBooks");
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public IActionResult RejectRequest(string userId, string isbn)
        {
            try
            {
                using (var connection = _dbContext.CreateConnection())
                {
                    var query = @"DELETE FROM UserRequest WHERE Id = @UserId AND ISBN = @ISBN";
                    connection.Execute(query, new { UserId = userId, ISBN = isbn });
                    TempData["Success"] = "Request rejected successfully";
                }
            }
            catch (Exception ex)
            {
                TempData["Error"] = ex.Message;
            }
            return RedirectToAction("RequestedBooks");
        }

    }
}
