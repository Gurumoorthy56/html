﻿using LibraryManagementSystem.Interfaces;
using LibraryManagementSystem.Models;
using LibraryManagementSystem.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace LibraryManagementSystem.Controllers
{

    public class UserController : Controller
    {
        private readonly IApplicationUser applicationUser;
        public UserController(IApplicationUser user)
        {
            this.applicationUser = user;
        }


        [Authorize(Roles = "Admin")]
        [Authorize]
        public async Task<IActionResult> Index(int page = 1)
        {
            int pageSize = 10;
            int skip = (page - 1) * pageSize;

            var users = await applicationUser.Get();

            int totalUsers = users.Count();
            int totalPages = (int)Math.Ceiling((double)totalUsers / pageSize);

            var paginatedUsers = users.Skip(skip).Take(pageSize).ToList();

            var model = new ApplicationUserListViewModel
            {
                Users = paginatedUsers,
                CurrentPage = page,
                TotalPages = totalPages
            };

            return View(model);
        }

        public async Task<IActionResult> GetAllUsers()
        {
            var Users = await applicationUser.Get();
            return Json(Users);
        }

        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {

                return View(Index);
            }
            var user = await applicationUser.Find(id);

            if (user == null)
            {

                return NotFound();
            }

            return View(user);
        }

        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var user = await applicationUser.Find(id);

            if (user == null)
            {
                return BadRequest();
            }
            return View("Delete", user);
        }

        [Authorize(Roles = "Admin")]
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ConfirmDelete(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return BadRequest("ID cannot be null or empty.");
            }
            var user = await applicationUser.Find(id);
            await applicationUser.Remove(user);
            return RedirectToAction(nameof(Index));
        }

    }
}
