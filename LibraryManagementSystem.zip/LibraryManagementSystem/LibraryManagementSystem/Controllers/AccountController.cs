﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using LibraryManagementSystem.Models;
using LibraryManagementSystem.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using System.Security.Claims;
using System.Threading.Tasks;
using static LibraryManagementSystem.Services.UserService;

namespace LibraryManagementSystem.Controllers
{
    public class AccountController : Controller
    {
        private readonly IUserService _userService;

        public AccountController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginModel model)
        {
            if (ModelState.IsValid)
            {
                ApplicationUser loggedInUser;
                var result = _userService.LoginUser(model, out loggedInUser);

                switch (result)
                {
                    case LoginResult.Success:
                        var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, loggedInUser.UserName),
                    new Claim(ClaimTypes.Role, loggedInUser.Role)
                };
                        var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                        var authProperties = new AuthenticationProperties
                        {
                            IsPersistent = true
                        };
                        await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,
                            new ClaimsPrincipal(claimsIdentity), authProperties);

                        HttpContext.Session.SetString("Username", loggedInUser.UserName);
                        HttpContext.Session.SetString("Name", loggedInUser.Name);
                        HttpContext.Session.SetString("UserId", loggedInUser.Id.ToString());
                        HttpContext.Session.SetString("Role", loggedInUser.Role);

                        TempData["LoginSuccess"] = "Successfully logged in!";

                        if (loggedInUser.Role == "Admin")
                            return RedirectToAction("Index", "Books");
                        return RedirectToAction("Index", "Home");

                    case LoginResult.EmailNotFound:
                        ViewBag.error = "Email not registered";
                        return View(model);

                    case LoginResult.InvalidPassword:
                        ViewBag.error = "Invalid password";
                        return View(model);
                }
            }

            return View(model);
        }
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpGet]
        public IActionResult AccessDenied()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(RegisterModel model)
        {
            if (ModelState.IsValid)
            {
                var result = _userService.RegisterUser(model);

                switch (result)
                {
                    case RegisterResult.Success:
                        TempData["SuccessMessage"] = "Registration successful! Please login.";
                        return RedirectToAction("Login");

                    case RegisterResult.EmailExists:
                        ModelState.AddModelError("Email", "This email is already registered.");
                        return View(model);

                    case RegisterResult.Error:
                        ModelState.AddModelError("", "An error occurred during registration. Please try again.");
                        return View(model);
                }
            }

            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> Logout()
        {
            // Clear session
            HttpContext.Session.Clear();

            // Sign out the user and remove the authentication cookie
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);

            // Redirect to login page after logging out
            return RedirectToAction("Login");
        }
    }
}
