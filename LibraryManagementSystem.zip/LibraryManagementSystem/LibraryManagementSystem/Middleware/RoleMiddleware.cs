﻿using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;


namespace LibraryManagementSystem.Middleware
{
    public class RoleMiddleware
    {
        private readonly RequestDelegate _next;

        public RoleMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            var role = context.Session.GetString("Role");
            var path = context.Request.Path;

            if (path.StartsWithSegments("/Admin") && role != "Admin")
            {
                context.Response.Redirect("/Account/AccessDenied");
                return;
            }
            //if (path.StartsWithSegments("/Home") && role != "User")
            //{
            //    context.Response.Redirect("/Account/AccessDenied");
            //    return;
            //}
            //if (path.StartsWithSegments("/Books/Create") && role != "Admin")
            //{
            //    context.Response.Redirect("/Account/AccessDenied");
            //    return;
            //}
            //if (path.StartsWithSegments("/Books/Delete") && role != "Admin")
            //{
            //    context.Response.Redirect("/Account/AccessDenied");
            //    return;
            //}
            //if (path.StartsWithSegments("/Books/Edit") && role != "Admin")
            //{
            //    context.Response.Redirect("/Account/AccessDenied");
            //    return;
            //}

            await _next(context);
        }
    }
}
