﻿

namespace LibraryManagementSystem.Models
{
    public class BookListViewModel
    {
        public List<BookModel> Books { get; set; } // The list of books to display
        public int CurrentPage { get; set; }  // Current page number
        public int TotalPages { get; set; }   // Total number of pages
    }
}
