﻿

namespace LibraryManagementSystem.Models
{
    public class UserRequestModel
    {
        public Guid Id { get; set; }
        public string ISBN { get; set; }
    }
}
