﻿

namespace LibraryManagementSystem.Models
{
    public class UserWishlistModel
    {
        public string UserId { get; set; }
        public string ISBN { get; set; }
    }

}
