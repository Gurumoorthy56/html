﻿using System.ComponentModel.DataAnnotations;

namespace LibraryManagementSystem.Models
{
    public class BookModel
    {
        [Display(Name = "ISBN")]
        [Required(ErrorMessage = "ISBN is required.")]
        [StringLength(17, ErrorMessage = "ISBN must be 17 characters long.")]
        public string ISBN { get; set; }

        [Display(Name = "Book Title")]
        [Required(ErrorMessage = "Book title is required.")]
        [StringLength(255, ErrorMessage = "Book title cannot exceed 255 characters.")]
        public string BookTitle { get; set; }

        [Display(Name = "Author")]
        [Required(ErrorMessage = "Author name is required.")]
        [StringLength(100, ErrorMessage = "Author name cannot exceed 100 characters.")]
        public string Author { get; set; }

        [Display(Name = "About Author")]
        public string AboutAuthor { get; set; }

        [Display(Name = "Genre")]
        public string Genre { get; set; }

        [Display(Name = "Tags")]
        public string Tags { get; set; }

        [Display(Name = "Publish Year")]
        public int? PublishYear { get; set; }

        [Display(Name = "Publisher")]
        public string Publisher { get; set; }

        [Display(Name = "Number of Pages")]
        public int? NumberOfPages { get; set; }

        [Display(Name = "Price")]
        [Range(0.01, double.MaxValue, ErrorMessage = "Price must be a positive value.")]
        public decimal Price { get; set; }

        [Display(Name = "Edition")]
        public string Edition { get; set; }

        [Display(Name = "Language")]
        public string Language { get; set; }

        [Display(Name = "Summary")]
        public string Summary { get; set; }

        [Display(Name = "Cover Image URL")]
        public string CoverImage { get; set; }

        [Display(Name = "Contributor")]
        public string Contributor { get; set; }

        [Display(Name = "Added Date")]
        public DateTime AddedDate { get; set; }
    }
}
