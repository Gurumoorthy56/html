﻿namespace LibraryManagementSystem.Models
{
    public class ApplicationUserListViewModel
    {
        public List<ApplicationUser> Users { get; set; }
        public int CurrentPage { get; set; }
        public int TotalPages { get; set; }
    }
}
