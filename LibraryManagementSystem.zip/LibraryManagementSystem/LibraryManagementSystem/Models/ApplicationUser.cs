﻿using System;
using System.ComponentModel.DataAnnotations;

namespace LibraryManagementSystem.Models
{
    public class ApplicationUser
    {
        public Guid Id { get; set; }  // GUID for Id

        public string Name { get; set; }

        public string? ProfilePicture { get; set; }

        public string UserName { get; set; }

        public string Email { get; set; }

        public string PasswordHash { get; set; }

        public string? PhoneNumber { get; set; }

        public string AddressLine1 { get; set; }

        public string City { get; set; }

        public string? Code { get; set; }

        public string Country { get; set; }

        public string InvoiceEmail { get; set; }

        public string? Language { get; set; }

        public string LastName { get; set; }

        public string? PostalCode { get; set; }

        public string Salutation { get; set; }

        public string Street { get; set; }

        public string Telephone { get; set; }

        public string Role { get; set; }  // New Role property






        //public Guid Id { get; set; }  // GUID for Id

        //[Required(ErrorMessage = "Name is required.")]
        //[StringLength(100, ErrorMessage = "Name cannot exceed 100 characters.")]
        //public string Name { get; set; }

        //public string? ProfilePicture { get; set; }

        //[Required(ErrorMessage = "Username is required.")]
        //[StringLength(50)]
        //public string UserName { get; set; }

        //[EmailAddress(ErrorMessage = "Invalid email address.")]
        //public string Email { get; set; }

        //[Required(ErrorMessage = "PasswordHash is required.")]
        //public string PasswordHash { get; set; }

        //public string? PhoneNumber { get; set; }

        //[Required(ErrorMessage = "Address Line 1 is required.")]
        //[StringLength(200, ErrorMessage = "Address Line 1 cannot exceed 200 characters.")]
        //public string AddressLine1 { get; set; }

        //[Required(ErrorMessage = "City is required.")]
        //public string City { get; set; }

        //[StringLength(50)]
        //public string? Code { get; set; }

        //[Required(ErrorMessage = "Country is required.")]
        //public string Country { get; set; }

        //[Required(ErrorMessage = "Invoice Email is required.")]
        //[EmailAddress(ErrorMessage = "Invalid invoice email.")]
        //public string InvoiceEmail { get; set; }

        //[StringLength(50)]
        //public string? Language { get; set; }

        //[Required(ErrorMessage = "Last Name is required.")]
        //[StringLength(100, ErrorMessage = "Last Name cannot exceed 100 characters.")]
        //public string LastName { get; set; }

        //[StringLength(50)]
        //public string? PostalCode { get; set; }

        //[Required(ErrorMessage = "Salutation is required.")]
        //public string Salutation { get; set; }

        //[Required(ErrorMessage = "Street is required.")]
        //public string Street { get; set; }

        //[Required(ErrorMessage = "Telephone is required.")]
        //public string Telephone { get; set; }

        //[Required(ErrorMessage = "Role is required.")]
        //[StringLength(20)]
        //public string Role { get; set; }  // New Role property
    }
}
