﻿

namespace LibraryManagementSystem.Models
{
    public class UserBooksModel
    {
        public string Id { get; set; }
        public string ISBN { get; set; }
    }
}
