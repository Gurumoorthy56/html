﻿using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.Interfaces
{
    public interface IBook
    {
        Task<IEnumerable<BookModel>> Get();
        Task<BookModel> Find(string uid);
        Task<BookModel> Add(BookModel model);
        Task<BookModel> Update(BookModel model);
        Task<BookModel> Remove(BookModel model);
    }
}
