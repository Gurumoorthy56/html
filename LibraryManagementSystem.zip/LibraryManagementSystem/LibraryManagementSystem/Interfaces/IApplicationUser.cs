﻿using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.Interfaces
{
    public interface IApplicationUser
    {
        Task<IEnumerable<ApplicationUser>> Get();
        Task<ApplicationUser> Find(string id);
        Task<ApplicationUser> Remove(ApplicationUser model);
    }
}
